let hours_worked = [13;13;13]
